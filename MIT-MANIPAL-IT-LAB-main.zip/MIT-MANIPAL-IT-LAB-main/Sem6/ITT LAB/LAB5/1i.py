a=[1,2,3,4,5,4,3,2,1]
rev_a = a[::-1]
if(a==rev_a):
    print ("Palindrome")
else:
    print("Not Palindrome")
