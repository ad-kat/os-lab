a = {1,2,3,5,7,8,9}
b = {1,8,4,6,9}
print(a.union(b))
print(a.intersection(b))
print(a.difference(b))
print(b.difference(a))