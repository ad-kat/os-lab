function red() {
  document.getElementById("body").style.backgroundColor = "red";
}
function Yellow() {
  document.getElementById("body").style.backgroundColor = "Yellow";
}
function Blue() {
  document.getElementById("body").style.backgroundColor = "Blue";
}
function Green() {
  document.getElementById("body").style.backgroundColor = "Green";
}
function Orange() {
  document.getElementById("body").style.backgroundColor = "Orange";
}
