#include <stdlib.h>
#include <stdio.h>

int main()
{
    int a,b,sum;
    printf("enter the two numbers to add\n");
    scanf("%d%d",&a,&b);
    sum=a+b;
    printf("the sum of the two numbers is %d ",sum);
    return 0;
}
