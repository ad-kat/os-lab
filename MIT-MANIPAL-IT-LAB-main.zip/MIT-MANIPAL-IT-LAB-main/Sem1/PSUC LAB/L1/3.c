#include <stdio.h>
#include <stdlib.h>

int main()
{
    char x;
    printf("Enter the character\n");
    scanf("%c",&x);
    printf("\nThe ASCII value assigned to the character is %d",x);
    return 0;
}
