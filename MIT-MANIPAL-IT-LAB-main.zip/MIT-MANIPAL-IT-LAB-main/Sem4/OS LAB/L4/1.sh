#!/bin/bash
cp $1 copy-$1
